// ==UserScript==
// @name Красная Линия (видео)
// @namespace Violentmonkey Scripts
// @include /^https://www\.rline\.tv/programs/[^/]+/video-\d+/$/
// @grant none
// @require			 https://github.com/aakumykov/internet_for_blinds/raw/master/greasemonkey/lib/play_audio.js
// ==/UserScript==

playAudio('http://127.0.0.1/redline-video-opened.mp3');